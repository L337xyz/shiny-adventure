<div class="col-md-12 mlm-main-div" id="mlm-main-div">        
    <?php 
    wpmlm_user_area();
    ?>    
</div>