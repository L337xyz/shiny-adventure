<?php
define("WP_MLM_PAGE_PATH", plugins_url() . '/' . WP_MLM_PLUGIN_NAME . '/templates');